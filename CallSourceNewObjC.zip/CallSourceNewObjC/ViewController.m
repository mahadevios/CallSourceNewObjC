//
//  ViewController.m
//  CallSourceNewObjC
//
//  Created by mac on 05/10/17.
//  Copyright © 2017 Xanadutec. All rights reserved.
//

//webrtc steps https://stackoverflow.com/questions/37672080/webrtc-integration-in-ios-with-own-server
//https://www.codeproject.com/Articles/1073738/Building-a-Video-Chat-Web-App-with-WebRTC
//https://shanetully.com/2014/09/a-dead-simple-webrtc-example/
#import "ViewController.h"


@interface ViewController ()



@end

@implementation ViewController
@synthesize factory,peerConn,socket,iceCandidateArray,iceCandidateDictArray;

- (void)viewDidLoad
{
    [super viewDidLoad];
    
   // [self prepareConnectionPeer1:@""];
    
    iceCandidateArray = [NSMutableArray new];
    
    iceCandidateDictArray = [NSMutableArray new];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(setSDPGotFromServer:) name:NOTIFICATION_GET_SDP
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(setCandidatesGotFromServer:) name:NOTIFICATION_GET_CANDIDATES
                                               object:nil];
        // Do any additional setup after loading the view, typically from a nib.
}

-(void) setSDPGotFromServer:(NSNotification *)notification
{
    // check for signaling state also
    
    NSLog(@"conn state = %u",self.peerConn.iceConnectionState);
    NSLog(@"sig sate = %u",self.peerConn.signalingState);

    NSDictionary* dic = notification.object;
    
    NSDictionary* apsDict = [dic objectForKey:@"aps"];
    [apsDict valueForKey:@"alert"];
    NSString* sdp =[apsDict valueForKey:@"alert"];
    

    if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad )
    {
        [self handleIncomingOffer:sdp];
    }
    else
    {
      [self handleIncomingAnswer:sdp];
    }

}

-(void) setCandidatesGotFromServer:(NSNotification *)notification
{
   
    NSDictionary* dic = notification.object;
    NSDictionary* apsDict = [dic objectForKey:@"aps"];
    [apsDict valueForKey:@"alert"];
    NSString* candidates =[apsDict valueForKey:@"alert"];
    
    
    NSData *data1 = [candidates dataUsingEncoding:NSUTF8StringEncoding];
    NSError* err;
    NSArray* arr = [NSJSONSerialization JSONObjectWithData:data1 options:NSJSONReadingAllowFragments error:&err];
    
    for (int i = 0; i< arr.count; i++)
    {
        NSDictionary* dic = arr[i];
        
        RTCICECandidate *candidate = [[RTCICECandidate alloc] initWithMid:[dic valueForKey:SDP_MID]
                                                                        index:(int)[dic valueForKey:SDP_MLINE_INDEX]
                                                                       sdp:[dic valueForKey:CANDIDATE_SDP]];

        [self.peerConn addICECandidate:candidate];
    }
}
-(void)prepareConnectionPeer:(NSString*) sdp
{
    [RTCPeerConnectionFactory initializeSSL];
    
    self.factory = [[RTCPeerConnectionFactory alloc] init];
    
    RTCICEServer *iceServer = [[RTCICEServer alloc] initWithURI:[[NSURL alloc] initWithString:@"stun:stun.l.google.com:19302"] username:@"" password:@""];
    
    NSArray *iceServerArray = [[NSArray alloc] initWithObjects:iceServer, nil];
    
    self.peerConn = [self.factory peerConnectionWithICEServers:iceServerArray constraints:nil delegate:self];
    
    RTCMediaStream* localStream = [self.factory mediaStreamWithLabel:@"myAudioStream"];
    
    RTCAudioTrack* audioTarck = [self.factory audioTrackWithID:@"audio0"];
    
    [localStream addAudioTrack:audioTarck];
    
    [peerConn addStream:localStream];
    
}


-(void) createOffer
{
    
    NSArray *mandConst = [[NSArray alloc] initWithObjects:[[RTCPair alloc] initWithKey:@"OfferToReceiveAudio" value:@"true"], nil ];

    RTCMediaConstraints *constraints = [[RTCMediaConstraints alloc] initWithMandatoryConstraints:mandConst optionalConstraints:nil];
    
    [peerConn createOfferWithDelegate:self constraints:constraints];
}

-(void)handleIncomingAnswer:(NSString* )sdp
{
   
    RTCSessionDescription *remoteDesc = [[RTCSessionDescription alloc] initWithType:@"answer" sdp:sdp];
    
    [self.peerConn setRemoteDescriptionWithDelegate:self sessionDescription:remoteDesc];
}

-(void)handleIncomingOffer:(NSString* )sdp
{
        
    RTCSessionDescription *remoteDesc = [[RTCSessionDescription alloc] initWithType:@"offer" sdp:sdp];
    
    [self.peerConn setRemoteDescriptionWithDelegate:self sessionDescription:remoteDesc];
    
}



-(void)viewWillAppear:(BOOL)animated
{
   

}

//-(void) createSocketConnection
//{
//    self.socket = [[JFRWebSocket alloc] initWithURL:[NSURL URLWithString:@"ws://192.168.3.75:8080"] protocols:@[@"chat",@"superchat",@"echo-protocol"]];
//    
//    self.socket.delegate = self;
//    
//    [self.socket connect];
//
//   
//}
//
//-(void)websocketDidConnect:(JFRWebSocket*)socket
//{
//    NSLog(@"websocket is connected");
//}
//-(void)websocket:(JFRWebSocket*)socket didReceiveMessage:(NSString*)string
//{
//    NSLog(@"got some text: %@",string);
//    NSData *data = [string dataUsingEncoding:NSUTF8StringEncoding];
//    NSDictionary* jsonOutput = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
//    NSString* sdp = jsonOutput[@"sdp"];
//    NSString* user = jsonOutput[@"user"];
//
//    if ([user  isEqual: @"1"])
//    {
//        
//    }
//    else
//    {
//        [self handleIncomingAnswer:sdp];
//    }
//    NSLog(@"%@",jsonOutput);
//}
//-(void)websocket:(JFRWebSocket*)socket didReceiveData:(NSData*)data
//{
//    NSLog(@"got some binary data: %@",data);
////    NSString* json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
////    NSLog(@"%@", [NSString stringWithFormat:@"json = %@",json]);
//   // [self handleIncomingAnswer:[NSString stringWithFormat:@"%@",data]];
//    //NSString* string = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
//    //NSLog(@"op = %@",string);
//}

-(void)peerConnection:(RTCPeerConnection *)peerConnection addedStream:(RTCMediaStream *)stream
{
    NSLog(@"added");
//    NSURL* url =  [stream.audioTracks.lastObject absoluteURL];
//    NSData *data = [NSData dataWithContentsOfURL:url];
//    _audioPlayer = [[AVAudioPlayer alloc] initWithData:data error:nil];
//    [_audioPlayer play];

    if ( UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad )
    {
       NSLog(@"receive on ipad"); /* Device is iPad */
    }
    else
    {
     NSLog(@"receive on iphone");
    }
    
    RTCEAGLVideoView *renderView = [[RTCEAGLVideoView alloc] initWithFrame:CGRectMake(0,0,100, 100)];
    

   // [stream.audioTracks.lastObject addRenderer:renderView];
    
    
    
   
}

-(void)peerConnection:(RTCPeerConnection *)peerConnection didOpenDataChannel:(RTCDataChannel *)dataChannel
{

}
-(void)peerConnection:(RTCPeerConnection *)peerConnection removedStream:(RTCMediaStream *)stream
{

}

-(void)peerConnection:(RTCPeerConnection *)peerConnection gotICECandidate:(RTCICECandidate *)candidate
{
//    NSLog(@"candidate = %@", candidate);
//    
//    NSLog(@"candidate sdpmid = %@", candidate.sdpMid);
//    NSLog(@"candidate sdpmid = %ld", (long)candidate.sdpMLineIndex);
//    NSLog(@"candidate sdpmid = %ld", (long)candidate.sdp);

    
    [peerConnection addICECandidate:candidate];
    
    [iceCandidateArray addObject:candidate];

    NSMutableDictionary* dict = [NSMutableDictionary new];
    
    [dict setValue:candidate.sdpMid forKey:SDP_MID];
    [dict setValue:[NSString stringWithFormat:@"%ld",(long)candidate.sdpMLineIndex] forKey:SDP_MLINE_INDEX];
    [dict setValue:candidate.sdp forKey:CANDIDATE_SDP];

    [iceCandidateDictArray addObject:dict];
}


-(void)peerConnection:(RTCPeerConnection *)peerConnection iceGatheringChanged:(RTCICEGatheringState)newState
{

    if (newState == RTCICEGatheringComplete)
    {
        for (int i= 0; i<iceCandidateArray.count; i++)
        {
            
            [self.peerConn addICECandidate:(RTCICECandidate*)iceCandidateArray[i]];
        }
        
        if (iceCandidateArray.count > 0)
        {
            
            NSError *error;
            NSString* json, *json1;
            NSData *jsonData = [NSJSONSerialization dataWithJSONObject:iceCandidateDictArray options:NSJSONWritingPrettyPrinted error:&error];
            
            if (! jsonData) {
               
            } else {
               json = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
            }
            
            NSMutableDictionary* dict = [NSMutableDictionary new];
            
            [dict setValue:json forKey:@"dict"];
            
            NSData *jsonData1 = [NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:&error];
            
            if (! jsonData1) {
                return;
            } else {
                json1 = [[NSString alloc] initWithData:jsonData1 encoding:NSUTF8StringEncoding];
            }
            [[APIManager sharedManager] sendCandidateUsername:self.usernameTextFIeld.text candidate:json1];

        }
    }
}

-(void)peerConnection:(RTCPeerConnection *)peerConnection iceConnectionChanged:(RTCICEConnectionState)newState
{

    NSLog(@"Connection state: %u", newState);
}

-(void)peerConnectionOnRenegotiationNeeded:(RTCPeerConnection *)peerConnection
{

}


-(void)peerConnection:(RTCPeerConnection *)peerConnection signalingStateChanged:(RTCSignalingState)stateChanged
{
    NSLog(@"Signalling state: %u", stateChanged);
}

-(void)peerConnection:(RTCPeerConnection *)peerConnection didCreateSessionDescription:(RTCSessionDescription *)sdp error:(NSError *)error
{
    [peerConnection setLocalDescriptionWithDelegate:self sessionDescription:sdp];
    
    self.SDP = [NSString stringWithFormat:@"%@",sdp];
    
}

-(void)peerConnection:(RTCPeerConnection *)peerConnection didSetSessionDescriptionWithError:(NSError *)error
{
    if (peerConnection.signalingState == RTCSignalingHaveLocalOffer || (peerConnection.signalingState == RTCSignalingStable && [AppPreferences sharedAppPreferences]. isCalled == false))
    {
        // send sdp of offer and then for answer
      
        [AppPreferences sharedAppPreferences]. isCalled = true;
        
        [[APIManager sharedManager] sendSDPUsername:self.usernameTextFIeld.text SDP:self.SDP];
    }
    else
    if(peerConnection.signalingState == RTCSignalingHaveRemoteOffer)
    {
        NSArray *mandConst = [[NSArray alloc] initWithObjects:[[RTCPair alloc] initWithKey:@"OfferToReceiveAudio" value:@"true"], nil ];
        
        RTCMediaConstraints *constraints = [[RTCMediaConstraints alloc] initWithMandatoryConstraints:mandConst optionalConstraints:nil];
        
        [peerConnection createAnswerWithDelegate:self constraints:constraints];
    

    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




- (IBAction)socketWriteButtonClicked:(id)sender
{
   // [self.socket writeString:@"Hi server"];
    //[self.socket ]
}


- (IBAction)createOfferClicked:(id)sender
{
    [self createOffer];
}

- (IBAction)registerButtonClicked:(id)sender
{
     [[APIManager sharedManager] updateDevieTokenUsername:self.usernameTextFIeld.text andDeviceId:[AppPreferences sharedAppPreferences].deviceToken];
}
- (IBAction)initPeerButtonClicked:(id)sender
{
    [self prepareConnectionPeer:@""];
}


@end

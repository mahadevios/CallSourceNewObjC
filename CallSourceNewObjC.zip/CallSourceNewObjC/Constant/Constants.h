//
//  Constants.h
//  Communicator
//
//  Created by mac on 23/04/16.
//  Copyright © 2016 Xanadutec. All rights reserved.
//

#ifndef Constants_h
#define Constants_h

//http://localhost:9090/coreflex/
//http://115.249.195.23:8080/Xanadu_MT/

//#define  BASE_URL_PATH                  @"http://192.168.0.13:8080/coreflex/feedcom"
//#define  BASE_URL_PATH                  @"http://115.249.195.23:8080/Xanadu_MT/feedcom"
//#define  BASE_URL_PATH                  @"http://192.168.3.80:9090/coreflex/feedcom"   //sable

//#define  BASE_URL_PATH      @"http://192.168.0.13:7070/coreflex/feedcom"                       //kuldeep

//#define  BASE_URL_PATH                  @"http://192.168.3.75:9091/coreflex/feedcom"//   local

//#define HTTP_UPLOAD_PATH                @"http://localhost:9090/coreflex/resources/CfsFiles/"
//#define HTTP_UPLOAD_PATH                @"http://115.249.195.23:8080/Xanadu_MT/resources/CfsFiles/"
//http://115.249.195.23:8080/Communicator
//#define  BASE_URL_PATH                  @"http://115.249.195.23:8080/Communicator/feedcom"  //live server
//#define  BASE_URL_PATH                  @"http://115.249.195.23:9090/Communicator/feedcom/"  //live server

//#define  BASE_URL_PATH                  @"http://192.168.3.74:9090/coreflex/feedcom"
#define  BASE_URL_PATH                  @"http://192.168.3.165:8080/coreflex/feedcom"
//#define HTTP_UPLOAD_PATH                @"http://192.168.3.170:8080/coreflex/resources/CfsFiles/"  //nikhil sir server

#define FTPHostName                     @"@pantudantukids.com"
#define FTPFilesFolderName              @"/TEST/"
#define FTPUsername                     @"demoFtp%40pantudantukids.com"
#define FTPPassword                     @"asdf123"

#define  POST                           @"POST"
#define  GET                            @"GET"
#define  PUT                            @"PUT"
#define  REQUEST_PARAMETER              @"requestParameter"
#define  SUCCESS                        @"1000"
#define  FAILURE                        @"1001"
#define DATE_TIME_FORMAT                       @"yyyy-MM-dd HH:mm:ss"
#define  SDP_MID                        @"sdp_mid"
#define  SDP_MLINE_INDEX                @"sdp_mline_index"
#define  CANDIDATE_SDP                  @"candidate_sdp"

// API List
//#define  USER_LOGIN_API                @"getListOfFeedcomAndQueryComForCommunication"
#define NEW_USER_LOGIN_API                  @"login"
#define UPDATE_DEVICE_TOKEN_API             @"MahadevUpdateDeviceToken"
#define SEND_SDP_API                        @"MahadevSendNotificationWithSDP"
#define SEND_CANDIDATES_API                 @"MahadevSendNotificationWithCandidate"


//getListOfFeedcomForCommunication

//NSNOTIFICATION

//at login web services constants
#define NOTIFICATION_UPDATE_DEVICE_TOKEN            @"uodateDeviceToken"
#define NOTIFICATION_GET_SDP                        @"getSDP"
#define NOTIFICATION_GET_CANDIDATES                 @"getCandidates"




#endif /* Constants_h */

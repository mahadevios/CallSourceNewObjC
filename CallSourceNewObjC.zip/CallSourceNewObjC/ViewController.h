//
//  ViewController.h
//  CallSourceNewObjC
//
//  Created by mac on 05/10/17.
//  Copyright © 2017 Xanadutec. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RTCAudioSource.h"
#import "RTCAudioTrack.h"
#import "RTCAVFoundationVideoSource.h"
#import "RTCDataChannel.h"
#import "RTCEAGLVideoView.h"
#import "RTCFileLogger.h"
#import "RTCI420Frame.h"
#import "RTCICECandidate.h"
#import "RTCICEServer.h"
#import "RTCLogging.h"
#import "RTCMediaConstraints.h"
#import "RTCMediaSource.h"
#import "RTCMediaStream.h"
#import "RTCMediaStreamTrack.h"
//#import "RTCNSGLVideoView.h"
#import "RTCOpenGLVideoRenderer.h"
#import "RTCPair.h"
#import "RTCPeerConnection.h"
#import "RTCPeerConnectionDelegate.h"
#import "RTCPeerConnectionFactory.h"
#import "RTCPeerConnectionInterface.h"
#import "RTCSessionDescription.h"
#import "RTCSessionDescriptionDelegate.h"
#import "RTCStatsDelegate.h"
#import "RTCStatsReport.h"
#import "RTCTypes.h"
#import "RTCVideoCapturer.h"
#import "RTCVideoRenderer.h"
#import "RTCVideoSource.h"
#import "RTCVideoTrack.h"
#import <AVFoundation/AVFoundation.h>
#import "JFRWebSocket.h"

@interface ViewController : UIViewController<RTCPeerConnectionDelegate, RTCSessionDescriptionDelegate, JFRWebSocketDelegate>

@property(nonatomic,strong) RTCPeerConnectionFactory* factory;
@property(nonatomic,strong) RTCPeerConnection* peerConn;
@property(nonatomic,strong) JFRWebSocket* socket;
@property(nonatomic,strong) NSString* SDP;
@property(nonatomic,strong) NSMutableArray* iceCandidateArray;
@property(nonatomic,strong) NSMutableArray* iceCandidateDictArray;
@property (nonatomic, strong) AVAudioPlayer *audioPlayer;

- (IBAction)registerButtonClicked:(id)sender;
- (IBAction)initPeerButtonClicked:(id)sender;
- (IBAction)createOfferClicked:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *usernameTextFIeld;
@end

